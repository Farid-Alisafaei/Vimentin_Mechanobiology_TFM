% Farid Alisafaei (New Jersey Institute of Technology)
% Vimentin Intermediate Filaments Can Enhance or Abate Active Cellular Forces in a Microenvironmental Stiffness-Dependent Manner
% doi: https://doi.org/10.1101/2022.04.02.486829
% 
clear all
clc
%
global E_MT
global E_a
global Beta
global Alpha
global Rho0
global e_v1
global e_v2
global e_MT
global e_a
global L_v1
global L_v2
global m_v1
global m_v2
global L_MT
global m_MT
global L_a
global m_a
global RhoBar0
%
E_MT    = 9.000  ;         % stiffness of microtubules
E_a     = 0.500  ;         % initial stiffness of actin
Beta    = 1.200  ;         % chemical stiffness
Alpha   = 0.800  ;         % chemo-mechanical feedback parameter
Rho0    = 10.00  ;         % motor density in the quiescent state
%
e_a     = 0.150  ;         % critical strain for actin in tensile element
L_a     = 200.0  ;         % stiffening parameter for actin in tenile element
m_a     = 15.00  ;         % stiffening parameter for actin in tenile element
%
e_v2    = 0.000  ;         % critical strain for vimentin in tensile element
L_v2    = 0.000  ;         % stiffening parameter for vimentin in tensile element
m_v2    = 0.000  ;         % stiffening parameter for vimentin in tensile element
%
e_v1    = 0.000  ;         % critical strain for vimentin in contractile element
L_v1    = 0.000  ;         % stiffening parameter for vimentin in contractile element 
m_v1    = 0.000  ;         % stiffening parameter for vimentin in contractile element 
%
e_MT    = 0.000  ;         % critical strain for microtubule in contractile element
L_MT    = 0.000  ;         % stiffening parameter for microtubule in contractile element
m_MT    = 0.000  ;         % stiffening parameter for microtubule in contractile element
%
RhoBar0 = Beta * Rho0 / (Beta-Alpha) ;
%
%
% check parameter
if ( E_MT*Alpha <= 1 )
    disp('Error')
    disp('E_MT*Alpha <= 1')
    return
end
if ( Beta <= Alpha )
    disp('Error')
    disp('Beta <= Alpha')
    return
end
%
% micropost stiffness
E_p = linspace(2,40,200) ;  
%
% stiffness of vimentin in contractile element
E_v1 = linspace(0,10,200) ;
%
% factor to indicate the difference between vimentin in compression and tension
f = 0.6 ;
%
% stiffness of vimentin in tensile element
E_v2 = E_v1 / f ;
%
% initial guess
x0 = [0;0;0;0] ;
%
% strain in contractile element
Epsilon_1    = zeros(length(E_v1),length(E_p)) ;
%
% strain in tensile element
Epsilon_2    = zeros(length(E_v1),length(E_p)) ;
%
% strain in micropost element
Epsilon_p    = zeros(length(E_v1),length(E_p)) ;
%
% difference in strain of micropost element: v+/+ minus v-/-
dEpsilon_p   = zeros(length(E_v1),length(E_p)) ;
%
% difference in total cell strain:v+/+ minus v-/-
dCellStrain  = zeros(length(E_v1),length(E_p)) ;
%
% stress
Sigma        = zeros(length(E_v1),length(E_p)) ;
%
% stress difference: v+/+ minus v-/-
dSigma       = zeros(length(E_v1),length(E_p)) ;
%
% contractility
Rho          = zeros(length(E_v1),length(E_p)) ;
%
% contractility difference: v+/+ minus v-/-
dRho         = zeros(length(E_v1),length(E_p)) ;
%
% stiffness of tensile element
E_av         = zeros(length(E_v1),length(E_p)) ;
%
% stiffness of contractile element
E_mv         = zeros(length(E_v1),length(E_p)) ;
%
% total stiffness 
E_tot        = zeros(length(E_v1),length(E_p)) ;
%
% total stiffness difference: v+/+ minus v-/- 
dE_tot       = zeros(length(E_v1),length(E_p)) ;
%
% solving equations
for i = 1:length(E_v1)
    for j = 1:length(E_p)
        [x,iter] = newtonm( x0 , E_v1(i) , E_v2(i) , E_p(j) ) ;
        Epsilon_1(i,j)  = x(1) ;
        Epsilon_2(i,j)  = x(2) ;
        Epsilon_p(i,j)  = x(3) ;
        Sigma(i,j)      = x(4) ;
    end
end
%
% contractility and stiffness of contractile component
for i = 1:length(E_v1)
    for j = 1:length(E_p)
        EBar = E_MT + E_v1(i) ;
        if ( abs(Epsilon_1(i,j))>abs(e_v1) && abs(Epsilon_1(i,j))<=abs(e_MT) )
            EBar = E_MT                                                             + E_v1(i) * ( 1 + L_v1 * ((abs(Epsilon_1(i,j))-abs(e_v1))^(m_v1-0)) ) ;
        elseif ( abs(Epsilon_1(i,j))>abs(e_MT) )
            EBar = E_MT * ( 1 + L_MT * ((abs(Epsilon_1(i,j))-abs(e_MT))^(m_MT-0)) ) + E_v1(i) * ( 1 + L_v1 * ((abs(Epsilon_1(i,j))-abs(e_v1))^(m_v1-0)) ) ;
        end
        KpBar    = (EBar*Alpha-1)  / (Beta-Alpha)   ;
        KBar     = (EBar*Beta-1)   / (Beta-Alpha)   ;
        Rho(i,j) = KpBar * Epsilon_1(i,j) + RhoBar0 ;
        E_mv(i,j)= KBar                             ;
    end
end
%
% stiffness of tensile component
for i = 1:length(E_v1)
    for j = 1:length(E_p)
        E_av(i,j)       = E_a + E_v2(i) ;
        if ( (Epsilon_2(i,j)>e_a) && (Epsilon_2(i,j)<=e_v2) )
            E_av(i,j)   = E_a * ( 1 + L_a * ((Epsilon_2(i,j)-e_a)^m_a) ) + E_v2(i) ;
        elseif ( Epsilon_2(i,j)>e_v2 )
            E_av(i,j)   = E_a * ( 1 + L_a * ((Epsilon_2(i,j)-e_a)^m_a) ) + E_v2(i) * ( 1 + L_v2 * ((Epsilon_2(i,j)-e_v2)^m_v2) ) ;
        end
    end
end      
%
% total stiffness 
for i = 1:length(E_v1)
    for j = 1:length(E_p)
        E_tot(i,j) = E_av(i,j) * E_mv(i,j) / ( E_av(i,j) + E_mv(i,j) ) ;
    end
end
%
%--------------------------------------------------------------------------
%
a = 1   ;
c = 30  ;
disp([E_v1(a);E_v1(c)])
%
% stress
figure
plot( E_p , Sigma(a,:)/Sigma(a,1)   , 'b-' )
hold on
plot( E_p , Sigma(c,:)/Sigma(a,1)  , 'k-' )
title('stress')
%
% strain in micropost element
figure
plot( E_p , Epsilon_p(a,:)/Epsilon_p(a,1)   , 'b-' )
hold on
plot( E_p , Epsilon_p(c,:)/Epsilon_p(a,1)   , 'k-' )
title('strain in micropost element')
%
% contractility
figure
plot( E_p , Rho(a,:)/Rho(a,1) , 'b-' )
hold on
plot( E_p , Rho(c,:)/Rho(a,1)  , 'k-' )
title('contractility')




















